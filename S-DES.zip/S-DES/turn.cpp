#include "turn.h"
char str_to_char(string str)
{
    int a = (str[7]-48)+ (str[6] - 48)*2 + (str[5] - 48) * 4 + (str[4] - 48) * 8 +
            (str[3] - 48) * 16 + (str[2] - 48) * 32 + (str[1] - 48) * 64 + (str[0] - 48) * 128;

    return (char)a;
}

int* char_to_intarray(char a)
{
    int b=a;
    int *array=new int[9];
    for (int i = 1; i <= 8; i++)
    {
        array[9-i]=b%2;
        b/=2;
    }
    return array;
}
