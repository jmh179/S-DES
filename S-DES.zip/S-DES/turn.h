#ifndef TURN_H
#define TURN_H

#endif // TURN_H
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <QString>
using namespace std;

//各格式变量之间的转化

//string格式转char格式,用于将8位二进制数通过ascll转为一个字母
char str_to_char(string str);
//char格式转int格式的数组，用于将字符转为8位二进制数组
int* char_to_intarray(char a);
