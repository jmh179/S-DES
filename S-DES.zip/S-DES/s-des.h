#ifndef SDES_H
#define SDES_H

#endif // SDES_H
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

using namespace std;

void createkey(int k[11], int k1[9], int k2[9]);
void f(int R[], int K[]);

string Encode(int ming[9], int k1[], int k2[]);

string Decode(int ming[9], int k1[], int k2[]);




