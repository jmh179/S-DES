#include "widget.h"
#include "ui_widget.h"
#include<qstring.h>


Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}



void Widget::on_pushButton_clicked()
{
    int k[11], k1[9], k2[9];
    QString k_cin=ui->lineEdit->text();
    for (int i = 1; i <= 10; i++)
    {
        k[i]=QString(k_cin[i-1]).toInt();
    }
    createkey(k, k1, k2);
    int ming[9];
    QString ming_cin=ui->lineEdit_2->text();
    for (int i = 1; i <= 8; i++)
    {
        ming[i]=QString(ming_cin[i-1]).toInt();
    }
    string mi;
    mi=Encode(ming, k1, k2);
    ui->label_3->setText(QString::fromStdString(mi));

}


void Widget::on_pushButton_2_clicked()
{
    int k[11], k1[9], k2[9];
    QString k_cin=ui->lineEdit_3->text();
    for (int i = 1; i <= 10; i++)
    {
        k[i]=QString(k_cin[i-1]).toInt();
    }
    createkey(k, k1, k2);
    int mi[9];
    QString mi_cin=ui->lineEdit_4->text();
    for (int i = 1; i <= 8; i++)
    {
        mi[i]=QString(mi_cin[i-1]).toInt();
    }
    string ming;
    ming=Decode(mi, k1, k2);
    ui->label_8->setText(QString::fromStdString(ming));
}


void Widget::on_pushButton_3_clicked()
{
    int k[11], k1[9], k2[9];
    QString k_cin=ui->lineEdit_5->text();
    for (int i = 1; i <= 10; i++)
    {
        k[i]=QString(k_cin[i-1]).toInt();
    }
    createkey(k, k1, k2);
    string ming_cin=(ui->lineEdit_6->text()).toStdString();
    int len=ming_cin.length();
    string mi=ming_cin;
    for (int i=0;i<len;i++)//从左到右依此处理每个字符，并填入
    {
        int* a=char_to_intarray(ming_cin[i]);//将字符转为二进制数组
        string x=Encode(a, k1, k2);
        mi[i]=str_to_char(x);
    }
    ui->label_16->setText(QString::fromStdString(mi));
}


void Widget::on_pushButton_4_clicked()
{
    int k[11], k1[9], k2[9];
    QString k_cin=ui->lineEdit_7->text();
    for (int i = 1; i <= 10; i++)
    {
        k[i]=QString(k_cin[i-1]).toInt();
    }
    createkey(k, k1, k2);
    string mi_cin=(ui->lineEdit_8->text()).toStdString();
    int len=mi_cin.length();
    string ming=mi_cin;
    for (int i=0;i<len;i++)//从左到右依此处理每个字符，并填入
    {
        int* a=char_to_intarray(mi_cin[i]);//将字符转为二进制数组
        string x=Decode(a, k1, k2);
        ming[i]=str_to_char(x);
    }
    ui->label_17->setText(QString::fromStdString(ming));
}


void Widget::on_pushButton_5_clicked()
{
    int k[11], k1[9], k2[9];
    QString k_cin=ui->lineEdit_5->text();
    for (int i = 1; i <= 10; i++)
    {
        k[i]=QString(k_cin[i-1]).toInt();
    }
    createkey(k, k1, k2);
    string mi_cin=(ui->label_16->text()).toStdString();
    int len=mi_cin.length();
    string ming=mi_cin;
    for (int i=0;i<len;i++)//从左到右依此处理每个字符，并填入
    {
        int* a=char_to_intarray(mi_cin[i]);//将字符转为二进制数组
        string x=Decode(a, k1, k2);
        ming[i]=str_to_char(x);
    }
    ui->label_17->setText(ui->lineEdit_6->text());
}

