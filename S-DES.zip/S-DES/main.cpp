#include<windows.h>
#include "widget.h"
#include <QApplication>

int main(int argc, char *argv[])
{

    QFont font;
    font.setPointSize(11);
    QApplication a(argc, argv);
    Widget w;
    w.show();
    return a.exec();
}
