#include"s-des.h"

int S1[4][4][2] = { {{0,1},{0,0},{1,1},{1,0}},
                   {{1,1},{1,0},{0,1},{0,0}},
                   {{0,0},{1,0},{0,1},{1,1}},
                   {{1,1},{0,1},{0,0},{1,0}} };
int S2[4][4][2] = { {{0,0},{0,1},{1,0},{1,1}},
                   {{1,0},{1,1},{0,1},{0,0}},
                   {{1,1},{0,0},{0,1},{1,0}},
                   {{1,0},{0,1},{0,0},{1,1}} };
void createkey(int k[11], int k1[9], int k2[9])
{
    int temp[11];
    temp[1] = k[3], temp[2] = k[5], temp[3] = k[2], temp[4] = k[7], temp[5] = k[4], temp[6] = k[10], temp[7] = k[1], temp[8] = k[9], temp[9] = k[8], temp[10] = k[6];
    int l[6], r[6];
    for (int i = 1; i <= 5; i++)
        l[i] = temp[i], r[i] = temp[i + 5];
    int x1, x2;
    x1 = l[1], x2 = r[1];
    for (int i = 2; i <= 5; i++)
        l[i - 1] = l[i], r[i - 1] = r[i];
    l[5] = x1;
    r[5] = x2;
    for (int i = 1; i <= 5; i++)
        temp[i] = l[i], temp[i + 5] = r[i];
    k1[1] = temp[6], k1[2] = temp[3], k1[3] = temp[7], k1[4] = temp[4], k1[5] = temp[8], k1[6] = temp[5], k1[7] = temp[10], k1[8] = temp[9];
    x1 = l[1], x2 = r[1];
    for (int i = 2; i <= 5; i++)
        l[i - 1] = l[i], r[i - 1] = r[i];
    l[5] = x1;
    r[5] = x2;
    for (int i = 1; i <= 5; i++)
        temp[i] = l[i], temp[i + 5] = r[i];
    k2[1] = temp[6], k2[2] = temp[3], k2[3] = temp[7], k2[4] = temp[4], k2[5] = temp[8], k2[6] = temp[5], k2[7] = temp[10], k2[8] = temp[9];
}
void f(int R[], int K[])
{
    int temp[9];
    temp[1] = R[4], temp[2] = R[1], temp[3] = R[2], temp[4] = R[3], temp[5] = R[2], temp[6] = R[3], temp[7] = R[4], temp[8] = R[1];
    for (int i = 1; i <= 8; i++)
        temp[i] = temp[i] ^ K[i];
    int s1[5], s2[5];
    for (int i = 1; i <= 4; i++)
        s1[i] = temp[i], s2[i] = temp[i + 4];
    int x1 = S1[s1[1] * 2 + s1[4]][s1[2] * 2 + s1[3]][0], x2 = S1[s1[1] * 2 + s1[4]][s1[2] * 2 + s1[3]][1];
    int x3 = S2[s2[1] * 2 + s2[4]][s2[2] * 2 + s2[3]][0], x4 = S2[s2[1] * 2 + s2[4]][s2[2] * 2 + s2[3]][1];
    R[1] = x2, R[2] = x4, R[3] = x3, R[4] = x1;
}
string Encode(int ming[9], int k1[], int k2[])
{
    int temp[9];
    temp[1] = ming[2], temp[2] = ming[6], temp[3] = ming[3], temp[4] = ming[1], temp[5] = ming[4], temp[6] = ming[8], temp[7] = ming[5], temp[8] = ming[7];
    int L0[5], R0[5], L1[5], R1[5], L2[5], R2[5];
    for (int i = 1; i <= 4; i++)
        L0[i] = temp[i], R0[i] = temp[i + 4];
    memcpy(L1, R0, sizeof(L1));
    f(R0, k1);
    for (int i = 1; i <= 4; i++)
        R1[i] = L0[i] ^ R0[i];
    memcpy(R2, R1, sizeof(R2));
    f(R1, k2);
    for (int i = 1; i <= 4; i++)
        L2[i] = L1[i] ^ R1[i];
    temp[1] = L2[4], temp[2] = L2[1], temp[3] = L2[3], temp[4] = R2[1], temp[5] = R2[3], temp[6] = L2[2], temp[7] = R2[4], temp[8] = R2[2];
    string mi="00000000";
    for (int i = 1; i <= 8; i++)
    {
        mi[i-1]=char(temp[i])+48;//将数组按位排入字符串
    }
    return mi;
}
string Decode(int mi[9], int k1[], int k2[])
{
    int temp[9];
    temp[1] = mi[2], temp[2] = mi[6], temp[3] = mi[3], temp[4] = mi[1], temp[5] = mi[4], temp[6] = mi[8], temp[7] = mi[5], temp[8] = mi[7];
    int L0[5], R0[5], L1[5], R1[5], L2[5], R2[5];
    for (int i = 1; i <= 4; i++)
        L2[i] = temp[i], R2[i] = temp[i + 4];
    memcpy(R1, R2, sizeof(R1));
    f(R2, k2);
    for (int i = 1; i <= 4; i++)
        L1[i] = L2[i] ^ R2[i];
    memcpy(R0, L1, sizeof(R0));
    f(L1, k1);
    for (int i = 1; i <= 4; i++)
        L0[i] = R1[i] ^ L1[i];
    temp[1] = L0[4], temp[2] = L0[1], temp[3] = L0[3], temp[4] = R0[1], temp[5] = R0[3], temp[6] = L0[2], temp[7] = R0[4], temp[8] = R0[2];
    string ming="00000000";
    for (int i = 1; i <= 8; i++)
    {
        ming[i-1]=char(temp[i])+48;
    }
    return ming;
}




